 Qtile layout color variations 
 
 Qtile: https://github.com/qtile/qtile
 Modified by: Tuncay D.
 Date: 2022-04-10
 LICENSE: [MIT LICENSE](LICENSE)
 
 These are color variations from default Qtile layout icons, found in my local
 installation directory at
 "/usr/lib/python3.10/site-packages/libqtile/resources/layout-icons".  These
 can be displayed with the
 [widget.CurrentLayoutIcon](https://docs.qtile.org/en/latest/manual/ref/widgets.html#currentlayouticon)
 in example.
